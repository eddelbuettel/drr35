
/* Name of package */
#define PACKAGE "littler"

/* Version number of package */
#define VERSION "0.2.9.1"
