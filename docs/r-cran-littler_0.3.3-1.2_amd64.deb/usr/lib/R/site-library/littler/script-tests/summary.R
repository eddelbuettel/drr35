#!/usr/bin/env r

print(summary(as.integer(readLines())));
